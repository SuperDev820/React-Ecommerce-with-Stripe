//sample categories data
const categories = [
    {
        name: 'Electronics',
        description: 'World Famous Electronics Products'
    },
    {
        name: 'Shoes',
        description: 'World Famous Electronics Products'
    },
]

export default categories